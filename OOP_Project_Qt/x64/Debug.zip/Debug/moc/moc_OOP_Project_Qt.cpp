/****************************************************************************
** Meta object code from reading C++ file 'OOP_Project_Qt.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../OOP_Project_Qt.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'OOP_Project_Qt.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS = QtMocHelpers::stringData(
    "OOP_Project_Qt",
    "openMainWindow",
    "",
    "openRecipeInputWindow",
    "openRecipeListWindow",
    "openRecipeViewWindow",
    "QModelIndex",
    "InputRecipeInfo",
    "openRecipeInputWindowForEdit",
    "deleteRecipeInfo",
    "deleteThisRecipeInfo",
    "setRecipeSearchInfo",
    "openDateInputWindow",
    "openDateListWindow",
    "openDateViewWindow",
    "InputDateInfo",
    "deleteDateInfo",
    "openDateInputWindowForEdit",
    "deleteThisDateInfo",
    "setDateSearchInfo"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS_t {
    uint offsetsAndSizes[40];
    char stringdata0[15];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[22];
    char stringdata4[21];
    char stringdata5[21];
    char stringdata6[12];
    char stringdata7[16];
    char stringdata8[29];
    char stringdata9[17];
    char stringdata10[21];
    char stringdata11[20];
    char stringdata12[20];
    char stringdata13[19];
    char stringdata14[19];
    char stringdata15[14];
    char stringdata16[15];
    char stringdata17[27];
    char stringdata18[19];
    char stringdata19[18];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS_t qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14),  // "OOP_Project_Qt"
        QT_MOC_LITERAL(15, 14),  // "openMainWindow"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 21),  // "openRecipeInputWindow"
        QT_MOC_LITERAL(53, 20),  // "openRecipeListWindow"
        QT_MOC_LITERAL(74, 20),  // "openRecipeViewWindow"
        QT_MOC_LITERAL(95, 11),  // "QModelIndex"
        QT_MOC_LITERAL(107, 15),  // "InputRecipeInfo"
        QT_MOC_LITERAL(123, 28),  // "openRecipeInputWindowForEdit"
        QT_MOC_LITERAL(152, 16),  // "deleteRecipeInfo"
        QT_MOC_LITERAL(169, 20),  // "deleteThisRecipeInfo"
        QT_MOC_LITERAL(190, 19),  // "setRecipeSearchInfo"
        QT_MOC_LITERAL(210, 19),  // "openDateInputWindow"
        QT_MOC_LITERAL(230, 18),  // "openDateListWindow"
        QT_MOC_LITERAL(249, 18),  // "openDateViewWindow"
        QT_MOC_LITERAL(268, 13),  // "InputDateInfo"
        QT_MOC_LITERAL(282, 14),  // "deleteDateInfo"
        QT_MOC_LITERAL(297, 26),  // "openDateInputWindowForEdit"
        QT_MOC_LITERAL(324, 18),  // "deleteThisDateInfo"
        QT_MOC_LITERAL(343, 17)   // "setDateSearchInfo"
    },
    "OOP_Project_Qt",
    "openMainWindow",
    "",
    "openRecipeInputWindow",
    "openRecipeListWindow",
    "openRecipeViewWindow",
    "QModelIndex",
    "InputRecipeInfo",
    "openRecipeInputWindowForEdit",
    "deleteRecipeInfo",
    "deleteThisRecipeInfo",
    "setRecipeSearchInfo",
    "openDateInputWindow",
    "openDateListWindow",
    "openDateViewWindow",
    "InputDateInfo",
    "deleteDateInfo",
    "openDateInputWindowForEdit",
    "deleteThisDateInfo",
    "setDateSearchInfo"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSOOP_Project_QtENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  116,    2, 0x0a,    1 /* Public */,
       3,    0,  117,    2, 0x0a,    2 /* Public */,
       4,    0,  118,    2, 0x0a,    3 /* Public */,
       5,    1,  119,    2, 0x0a,    4 /* Public */,
       7,    0,  122,    2, 0x0a,    6 /* Public */,
       8,    0,  123,    2, 0x0a,    7 /* Public */,
       9,    0,  124,    2, 0x0a,    8 /* Public */,
      10,    0,  125,    2, 0x0a,    9 /* Public */,
      11,    0,  126,    2, 0x0a,   10 /* Public */,
      12,    0,  127,    2, 0x0a,   11 /* Public */,
      13,    0,  128,    2, 0x0a,   12 /* Public */,
      14,    0,  129,    2, 0x0a,   13 /* Public */,
      15,    0,  130,    2, 0x0a,   14 /* Public */,
      16,    0,  131,    2, 0x0a,   15 /* Public */,
      17,    0,  132,    2, 0x0a,   16 /* Public */,
      18,    0,  133,    2, 0x0a,   17 /* Public */,
      19,    0,  134,    2, 0x0a,   18 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject OOP_Project_Qt::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSOOP_Project_QtENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<OOP_Project_Qt, std::true_type>,
        // method 'openMainWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openRecipeInputWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openRecipeListWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openRecipeViewWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QModelIndex, std::false_type>,
        // method 'InputRecipeInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openRecipeInputWindowForEdit'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteRecipeInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteThisRecipeInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setRecipeSearchInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openDateInputWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openDateListWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openDateViewWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'InputDateInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteDateInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openDateInputWindowForEdit'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteThisDateInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setDateSearchInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void OOP_Project_Qt::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<OOP_Project_Qt *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->openMainWindow(); break;
        case 1: _t->openRecipeInputWindow(); break;
        case 2: _t->openRecipeListWindow(); break;
        case 3: _t->openRecipeViewWindow((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 4: _t->InputRecipeInfo(); break;
        case 5: _t->openRecipeInputWindowForEdit(); break;
        case 6: _t->deleteRecipeInfo(); break;
        case 7: _t->deleteThisRecipeInfo(); break;
        case 8: _t->setRecipeSearchInfo(); break;
        case 9: _t->openDateInputWindow(); break;
        case 10: _t->openDateListWindow(); break;
        case 11: _t->openDateViewWindow(); break;
        case 12: _t->InputDateInfo(); break;
        case 13: _t->deleteDateInfo(); break;
        case 14: _t->openDateInputWindowForEdit(); break;
        case 15: _t->deleteThisDateInfo(); break;
        case 16: _t->setDateSearchInfo(); break;
        default: ;
        }
    }
}

const QMetaObject *OOP_Project_Qt::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OOP_Project_Qt::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSOOP_Project_QtENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int OOP_Project_Qt::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
